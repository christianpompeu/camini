---
name: Nutre Clinical Precision
colors:
  surface: '#fdf7ff'
  surface-dim: '#dfd7eb'
  surface-bright: '#fdf7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f1ff'
  surface-container: '#f3eaff'
  surface-container-high: '#ede5fa'
  surface-container-highest: '#e7dff4'
  on-surface: '#1d1928'
  on-surface-variant: '#494552'
  inverse-surface: '#322e3e'
  inverse-on-surface: '#f5eeff'
  outline: '#7a7483'
  outline-variant: '#cbc3d4'
  surface-tint: '#6a49b8'
  primary: '#502b9c'
  on-primary: '#ffffff'
  primary-container: '#6846b5'
  on-primary-container: '#ddcdff'
  inverse-primary: '#d0bcff'
  secondary: '#685490'
  on-secondary: '#ffffff'
  secondary-container: '#d3bbff'
  on-secondary-container: '#5c4883'
  tertiary: '#354935'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c614c'
  on-tertiary-container: '#c3dbc0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#522e9e'
  secondary-fixed: '#ebddff'
  secondary-fixed-dim: '#d3bbff'
  on-secondary-fixed: '#230e48'
  on-secondary-fixed-variant: '#503c76'
  tertiary-fixed: '#d1e9ce'
  tertiary-fixed-dim: '#b5cdb2'
  on-tertiary-fixed: '#0c200f'
  on-tertiary-fixed-variant: '#374c38'
  background: '#fdf7ff'
  on-background: '#1d1928'
  surface-variant: '#e7dff4'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  tabular-data:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.005em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system embodies a modern, clinical, high-utility aesthetic tailored for clinical nutritionists. Combining the austere precision of contemporary developer tooling (shadcn/ui ethos) with the tactile calm of wellness and clinical diagnostics, the visual language balances high-density data management with therapeutic serenity.

### Personality & Tone
- **Authoritative & Clinical:** Instills immediate trust, compliance, and scientific rigor.
- **Cognitively Light:** Eliminates visual friction during back-to-back consultations and complex diet plan calculations.
- **Refined Minimalism:** Relies on crisp structural grids, featherweight structural dividers, and deliberate micro-interactions over ornamental gradients or decorative graphics.

### Visual Style
- **Aesthetic Direction:** Contemporary Minimalist Clinical SaaS.
- **Architectural Framing:** Clean, pure white planar surfaces layered over a subtle lavender-tinted neutral canvas (`#F5F1FC`), bounded by deliberate 1px structural borders (`#EAE5F2`).
- **Data Density:** High scannability, tabular efficiency, tactile form controls, and strict typographic hierarchy engineered for prolonged clinical workflows.

## Colors

The palette balances clinical authority with ergonomic comfort, avoiding eye fatigue during extended use.

### Color Roles & Application
- **Primary (`#6846B5`):** Reserved for core high-intent actions, selected navigation items, primary interactive states, and essential data metrics.
- **Secondary (`#B8A1E3`):** Utilized for active focus rings, subtle interactive hover fills, secondary indicators, and delicate borders on active table rows.
- **Tertiary / Success (`#93AA91`):** A soft sage green applied to completed nutritional targets, confirmed clinical consultations, and positive biometric variations.
- **Warning / Attention (`#DCA76B`):** A warm amber for pending diet approvals, approaching patient milestones, and biochemical parameter warnings.
- **Canvas & Surfaces:**
  - `Surface Pure (#FFFFFF)`: Standard container cards, data tables, sheets, and popovers.
  - `Canvas Canvas (#F5F1FC)`: Foundation background providing high visual separation without harsh contrast.
  - `Surface Sidebar (#1E1B26)`: Deep dark slate alternative for a high-contrast collapsible sidebar navigation.
- **Borders & Dividers (`#EAE5F2` / `#E2DCED`):** Defines architectural partitions, input outlines, and table row separations with razor-sharp fidelity.
- **Text & Foreground:**
  - `Foreground Primary (#282433)`: High-legibility deep graphite for headers, values, and essential text.
  - `Foreground Muted (#6B6678)`: Medium slate gray for metadata, unit descriptors, and field placeholders.

## Typography

Typographic scale is constructed for high informational density and legibility across anthropometric logs, macro-nutrient distributions, and clinical notes.

- **Display & Section Headers (`Plus Jakarta Sans`):** Provides a modern, approachable structural presence that avoids clinical coldness while retaining authoritative weight.
- **Interface & Tabular Data (`Geist`):** Engineered with crisp geometric terminals and strict proportional spacing, optimal for dense clinical tables, dosage units (g, kcal, mg), and quick dashboard scans.
- **Tabular Features:** Enable `font-variant-numeric: tabular-nums lining-nums` across all numeric readouts, calorie logs, and financial tables to ensure vertical alignment.

## Layout & Spacing

The layout is built upon an 8pt grid with 4pt micro-increments, prioritizing dense, scannable data layouts.

### Structural Framework
- **Master Canvas Structure:**
  - **Collapsible Sidebar:** Fixed-width `240px` (desktop expanded) collapsing to `64px` (icon mode). Stays docked to the left with seamless vertical partition borders.
  - **Top Navigation Bar:** Sticky `56px` height containing the command search trigger (`Ctrl+K`), quick patient action modals, system notifications, and practitioner profile controls.
  - **Workspace Canvas:** Fluid container with max-width bounding at `1600px` for multi-column meal plan builders and patient comparison sheets.

### Breakpoints & Adaptive Rules
- **Desktop (≥ 1280px):** 12-column layout. Multi-pane workflows (e.g., patient sidebar + diet builder + nutritional summary).
- **Tablet (768px – 1279px):** 8-column layout. Sidebar collapses to icon rail (64px) or off-canvas drawer. Secondary summary panels collapse into bottom drawers or slide-in sheets.
- **Mobile (< 768px):** 4-column layout. Margin drops to `1rem` (`16px`). Table columns collapse using priority data rows with expandable drill-down drawers.

## Elevation & Depth

This system avoids heavy drop shadows, relying on structural borders, surface contrast, and ambient micro-depth for hierarchy.

### Depth Hierarchy
- **Level 0 (Flat / Base):** Surface pure cards (`#FFFFFF`) sitting directly on `#F5F1FC` Canvas, bound strictly by `1px solid #EAE5F2`. No shadow.
- **Level 1 (Interactive / Cards):** Rest state features `box-shadow: 0 1px 2px 0 rgba(40, 36, 51, 0.04)`. On hover, transitions smoothly to `box-shadow: 0 2px 8px -2px rgba(104, 70, 181, 0.08)` and border shifts to `#B8A1E3`.
- **Level 2 (Dropdowns & Popovers):** Elevated contextual menus, date pickers, and autocomplete results use `box-shadow: 0 4px 16px -2px rgba(40, 36, 51, 0.08)` with a `1px solid #E2DCED` outline.
- **Level 3 (Modals & Command Palettes):** Backdrop overlay tinted with `#1E1B26` at 40% opacity with `backdrop-filter: blur(4px)`. Centered dialog containers use `box-shadow: 0 12px 32px -4px rgba(40, 36, 51, 0.16)`.

## Shapes

The design uses a refined radius scale to maintain precision without visual harshness.

- **Standard Elements (`0.5rem` / `8px`):** Default for input fields, buttons, table cell wrappers, and standard card containers.
- **Small Elements (`0.375rem` / `6px`):** Badges, chip tags, tooltips, and sub-metric boxes within data tables.
- **Large Panels (`0.75rem` – `1rem` / `12px – 16px`): Dialog sheets, patient dossier overview blocks, and primary graph cards.
- **Circular (`9999px`):** Exclusively reserved for patient profile avatars, status notification pips, and round icon-only action triggers.

## Components

### Buttons
- **Primary:** Background `#6846B5`, text `#FFFFFF`, border `transparent`. Hover: `#57389B`. Focus: 2px ring `#B8A1E3` offset by 2px. Height: `36px` (compact) or `40px` (standard).
- **Secondary:** Background `#FFFFFF`, text `#282433`, border `1px solid #EAE5F2`. Hover: background `#F5F1FC`, border `#B8A1E3`.
- **Ghost:** Text `#282433`, no border. Hover: background `#F5F1FC`, text `#6846B5`.
- **Destructive:** Background `#FFF1F0`, text `#D9363E`, border `1px solid #FFCCC7`.

### Chips & Badges
- Compact padding (`2px 8px`), font size `11px` (`label-sm`), radius `6px`.
- **Success (Confirmed / Target Met):** Background `#F0F5F0`, text `#456343`, border `1px solid #D5E2D4`.
- **Pending / In Progress:** Background `#FDF6EC`, text `#96632B`, border `1px solid #F5DEB8`.
- **Primary Pill (Macro nutrients):** Background `#F5F1FC`, text `#6846B5`, border `1px solid #E2DCED`.

### Input Fields & Controls
- **Height:** `36px` default for form efficiency.
- **Surfaces:** `#FFFFFF` fill with `1px solid #EAE5F2` border.
- **Focus State:** Border shifts to `#6846B5` accompanied by `0 0 0 3px rgba(184, 161, 227, 0.25)`.
- **Checkboxes & Radios:** `16px x 16px`, `#6846B5` when checked with crisp white icon checkmark. Unchecked: `1px solid #E2DCED`.

### Cards & Container Panels
- Single continuous white background (`#FFFFFF`) with uniform `1px solid #EAE5F2` boundary.
- **Header Structure:** Explicit padding (`16px 20px`), separated from body via hairline divider or clear typographic grouping. Body padding: `20px`.

### High-Density Clinical Data Tables
- Header row height `36px`, background `#F5F1FC`, font `label-md` in `#6B6678`, uppercase with tracking.
- Row height `44px`, horizontal border `1px solid #EAE5F2`.
- Hover state: Row background transitions to `rgba(245, 241, 252, 0.65)`.
- Selected state: Background `#F5F1FC` with a `2px solid #6846B5` left border indicator.

### Command Palette (Ctrl+K)
- Centered modal container (`640px` max-width), positioned `15vh` from top.
- Integrated search bar with Lucide search icon, shortcut hints (`Esc`, `↑↓`), and segregated grouped results (Pacientes Recentes, Alimentos TACO/IBGE, Prescrições Rápidas).